#include "Hand.h"
using namespace std;

bool Hand::isFull(){
    return getSize() == MAX_CAPACITY;
}











